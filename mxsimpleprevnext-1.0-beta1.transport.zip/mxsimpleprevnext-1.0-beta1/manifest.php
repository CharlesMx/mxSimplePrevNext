<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => '--------------------
Extra: mxSimplePrevNext
--------------------
Version: 1.0 - beta1
Release: beta1
--------------------
 
This file is part of mxSimplePrevNext.

mxSimplePrevNext is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

mxSimplePrevNext is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with mxSimplePrevNext.  If not, see <http://www.gnu.org/licenses/>.
',
    'readme' => '--------------------
Extra: mxSimplePrevNext
--------------------
Version: 1.0 - beta1
Release: beta1
--------------------
 
A very simple snippet for creating sibling previous and next resource links based on a resource tree.

Sample Use: This sample returns the Next resource item based on the default sort order menu index.

[[!mxSimplePrevNext? &mxspnChunk=`nextResourceLink` &mxspnReturnType=`next` ]]


Parameters:
@mxspnPreviousDefault [string] = Default string to return if previoius resource is empty
@mxspnNextDefault [string] = Default string to return if next resource is empty
@mxspnReturnType [string; prev, next, both=default] = Set which button/links to return
@mxspnPrevious [boolean; default false] = Return only the previous resource item
@mxspnNext [boolean; default false] = Return only the next resource item
@mxspnChunk [string] = Chunk name to use to render results

For more information please visit http://charlesmx.com/software/mxsimpleprevnext.html
',
    'changelog' => '--------------------
Extra: mxSimplePrevNext
--------------------

Changelog for releases, please read log before submitting new issues.


--------------------
Version: 1.0
Release: beta1
--------------------
- First release, no changes.
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'b86b9240b5507bf8fa23b6070f9c8de7',
      'native_key' => 'mxsimpleprevnext',
      'filename' => 'modNamespace/4620f000ba739abca34195d979bcec54.vehicle',
      'namespace' => 'mxsimpleprevnext',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '261a5cc893db0b3232dd8cf5d1f8c5c4',
      'native_key' => 1,
      'filename' => 'modCategory/9ed1b72741cb1bae6433583a73001d8b.vehicle',
      'namespace' => 'mxsimpleprevnext',
    ),
  ),
);