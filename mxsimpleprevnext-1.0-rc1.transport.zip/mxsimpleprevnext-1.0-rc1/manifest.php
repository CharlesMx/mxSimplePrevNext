<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => '--------------------
Extra: mxSimplePrevNext
--------------------
Version: 1.0
Release: rc1
--------------------
 
This file is part of mxSimplePrevNext.

mxSimplePrevNext is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

mxSimplePrevNext is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with mxSimplePrevNext.  If not, see <http://www.gnu.org/licenses/>.
',
    'readme' => '--------------------
Extra: mxSimplePrevNext
--------------------
Version: 1.0
Release: rc1
--------------------
 
A very simple snippet for creating sibling previous and next resource links based on a resource tree.

Sample Use: This sample returns the Next resource item based on the default sort order menu index.

[[!mxSimplePrevNext? &mxspnChunk=`nextResourceLink` &mxspnReturnType=`next` ]]


Parameters:
@mxspnPreviousDefault [string] = Default string to return if previoius resource is empty
@mxspnNextDefault [string] = Default string to return if next resource is empty
@mxspnReturnType [string; prev, next, both=default] = Set which button/links to return
@mxspnPrevious [boolean; default false] = Return only the previous resource item
@mxspnNext [boolean; default false] = Return only the next resource item
@mxspnChunk [string] = Chunk name to use to render results

For more information please visit http://charlesmx.com/software/mxsimpleprevnext.html
',
    'changelog' => '--------------------
Extra: mxSimplePrevNext
--------------------

Changelog for releases, please read log before submitting new issues.


--------------------
Version: 1.0
Release: rc1
--------------------
- Bug Fix: Some configurations of PHP were not resolving the named scope of the core call in the snippet. (
- @mxspnSortBy [added] - New parameter to change what page property to use as the sort order; support multiple in comma list and based on the order of the comma list (ex: )

--------------------
Version: 1.0
Release: beta1
--------------------
- First release, no changes.

',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'a7723df2c24b6000eea5a6acb46f5f0f',
      'native_key' => 'mxsimpleprevnext',
      'filename' => 'modNamespace/a25c703e48f26a412179bb3325726963.vehicle',
      'namespace' => 'mxsimpleprevnext',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'b6957eeb0ce5d6ab7149ed66c0cb2dab',
      'native_key' => 1,
      'filename' => 'modCategory/4d696af2196420265ebfbdc944c24c50.vehicle',
      'namespace' => 'mxsimpleprevnext',
    ),
  ),
);