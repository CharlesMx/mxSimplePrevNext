--------------------
Extra: mxSimplePrevNext
--------------------
Version: 1.0 - beta1
Release: beta1
--------------------
 
A very simple snippet for creating sibling previous and next resource links based on a resource tree.

Sample Use: This sample returns the Next resource item based on the default sort order menu index.

[[!mxSimplePrevNext? &mxspnChunk=`nextResourceLink` &mxspnReturnType=`next` ]]


Parameters:
@mxspnPreviousDefault [string] = Default string to return if previoius resource is empty
@mxspnNextDefault [string] = Default string to return if next resource is empty
@mxspnReturnType [string; prev, next, both=default] = Set which button/links to return
@mxspnPrevious [boolean; default false] = Return only the previous resource item
@mxspnNext [boolean; default false] = Return only the next resource item
@mxspnChunk [string] = Chunk name to use to render results

For more information please visit http://charlesmx.com/software/mxsimpleprevnext.html
